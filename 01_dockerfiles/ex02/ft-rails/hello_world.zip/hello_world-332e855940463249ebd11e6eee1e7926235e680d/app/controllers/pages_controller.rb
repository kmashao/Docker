class PagesController < ApplicationController
  def home
    @greeting = "Home action says: Hello World! "
  end
end
